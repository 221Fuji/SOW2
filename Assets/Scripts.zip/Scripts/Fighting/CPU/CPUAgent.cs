using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine;


public abstract class CPUAgent : Agent
{
    [SerializeField] protected int _numActions;

    public FightingInputReceiver InputReciever { get; private set; }
    public int SelfCharaNum { get; private set; }
    public int EnemyCharaNum { get; private set; }
    public CharacterActions SelfCA { get; private set; }
    public CharacterActions EnemyCA { get; private set; }
    public CharacterState SelfCS { get; private set; }
    public CharacterState EnemysCS { get; private set; }


    public virtual void SetCAandCS()
    {
        InputReciever = GetComponent<FightingInputReceiver>();
        SelfCA = GetComponent<CharacterActions>();
        SelfCS = GetComponent<CharacterState>();
        EnemyCA = SelfCA.EnemyCA;
        EnemysCS = EnemyCA.GetComponent<CharacterState>();

        OnEpisodeStart();
    }

    protected virtual void OnEpisodeStart()
    {
        // �f���Q�[�g�̐ݒ�
        SelfCA.OnHurtAI += OnHurt;
        SelfCA.OnComboAI += OnCombo;
        SelfCA.OnDieAI += OnDie;
        SelfCA.OnBreakAI += OnBreak;
        SelfCA.OnMissAI += OnMiss;

        EnemyCA.OnHurtAI += OnHit;
        EnemyCA.OnGuardAI += OnGuarded;
        EnemyCA.OnDieAI += OnKill;
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // �����̊�{�����ϑ�
        sensor.AddObservation(SelfCA.HurtBox.transform.position);
        sensor.AddObservation(SelfCS.CurrentSP / SelfCS.MaxSP);
        sensor.AddObservation(SelfCS.CurrentUP / SelfCS.MaxUP);
        bool isSelfBroken = SelfCS.AnormalyStates.Contains(AnormalyState.Fatigue);
        sensor.AddObservation(isSelfBroken ? 1 : 0);

        // ����̊�{�����ϑ�
        sensor.AddObservation(EnemyCharaNum);
        sensor.AddObservation(EnemyCA.HurtBox.transform.position);
        bool isEnemyBroken = SelfCS.AnormalyStates.Contains(AnormalyState.Fatigue);
        sensor.AddObservation(isEnemyBroken ? 1 : 0);
    }

    private void Update()
    {
        if (SelfCS == null) return;

        if(SelfCS.AcceptOperations)
        {
            RequestDecision();
        }
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        int move = actions.DiscreteActions[0];

        // �Ⴆ�� 0 = Idle, 1 = Walk Left, 2 = Walk Right, 3 = Attack, 4 = Guard, ...
        switch (move)
        {
            case 0: InputReciever.SetWalkDirectionFromAI(0); break;
            case 1: InputReciever.SetWalkDirectionFromAI(-1f); break;
            case 2: InputReciever.SetWalkDirectionFromAI(1f); break;
            case 3: InputReciever.OnJump(); break;
            case 4: InputReciever.OnNomalMove(); break;
            case 5: InputReciever.OnSpecialMove1(); break;
            case 6: InputReciever.OnSpecialMove2(); break;
            case 7: InputReciever.OnUltimate(); break;
            case 8: InputReciever.SetGuardFromAI(true); break;
            case 9: InputReciever.SetGuardFromAI(false); break;
        }
    }

    public override void WriteDiscreteActionMask(IDiscreteActionMask actionMask)
    {
        for (int i = 3; i < _numActions; i++)
        {
            actionMask.SetActionEnabled(0, i, false);
        }

        if (SelfCA.CanJump)
        {
            actionMask.SetActionEnabled(0, 3, true);
        }

        if (SelfCA.CanGuard)
        {
            actionMask.SetActionEnabled(0, 8, true);
        }

        if (SelfCS.IsGuarding)
        {
            actionMask.SetActionEnabled(0, 9, true);
        }

        DiscreteUniqueActionMask(actionMask);
    }

    public abstract void DiscreteUniqueActionMask(IDiscreteActionMask actionMask);


    //�U�����������Ƃ�
    protected virtual void OnHurt()
    {
        AddReward(-1f);
    }

    //�U�����q�b�g�������Ƃ�
    protected virtual void OnHit()
    {
        AddReward(1f);
    }

    //�U�����K�[�h�������Ƃ�
    protected virtual void OnGuarded()
    {
        AddReward(0.75f);
    }

    //�U������U�肵���Ƃ�
    protected virtual void OnMiss()
    {
        AddReward(-0.25f);
    }

    //�R���{�����Ƃ�
    protected virtual void OnCombo()
    {
        AddReward(0.5f);
    }

    //���g��Break��ԂɂȂ����Ƃ�
    protected virtual void OnBreak()
    {
        AddReward(-2f);
    }

    //�|�����Ƃ�
    protected virtual void OnKill()
    {
        float reward = 2.5f;
        reward += (SelfCS.CurrentHP / SelfCS.MaxHP) * 2.5f;
        SetReward(reward);
        OnEpisodeEnd();
        EndEpisode();
    }

    //�|���ꂽ�Ƃ�
    protected virtual void OnDie()
    {
        float reward = -2.5f;
        reward -= (EnemysCS.CurrentHP/EnemysCS.MaxHP) * 2.5f;
        SetReward(reward);
        OnEpisodeEnd();
        EndEpisode();
    }

    private void OnEpisodeEnd()
    {
        float totalReward = GetCumulativeReward();

        Debug.Log($"Player{SelfCA.PlayerNum}����V:{totalReward}���l��");

        //�f���Q�[�g�̏�����
        SelfCA.OnHurtAI = null;
        SelfCA.OnComboAI = null;
        SelfCA.OnDieAI = null;
        SelfCA.OnGuardAI = null;
        SelfCA.OnBreakAI = null;
        SelfCA.OnMissAI = null;
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        // �J���p�Ƀe�X�g������L�q
    }
}
