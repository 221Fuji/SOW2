using Cysharp.Threading.Tasks;
using NUnit.Framework;
using System;
using System.Runtime.CompilerServices;
using System.Threading;
using UnityEngine;
using UnityEngine.InputSystem;


public abstract class FightingManager : ModeManager
{
    [SerializeField] private int _timeLimit;

    [SerializeField] private float _startPosX1P;
    [SerializeField] private float _startPosX2P;

    [SerializeField] private GameObject _camera;
    [SerializeField] private FightingUI _fightingUI;
    [SerializeField] private FightingEffectManager _effectManager;
    [Space]

    protected PlayerData _playerData1P;
    protected PlayerData _playerData2P;

    private RoundData _currentRoundData;
    private CancellationTokenSource _timeLimitCTS;
    //kinoko���M
    private BattleInfoLog _battleInfoLog;

    public RoundData CurrentRoundData { get => _currentRoundData; }


    private void Awake()
    {
        Application.targetFrameRate = 60; // �f�o�b�O�p
    }

    public void InitializeFM(CharacterData characterData1P, CharacterData characterData2P)
    {
        PlayerInput player1 = PlayerInput.Instantiate(
            prefab: characterData1P.CharacterPrefab.gameObject,
            playerIndex: 1,
            pairWithDevice: GameManager.Player1Device
            );
        PlayerInput player2 = PlayerInput.Instantiate(
            prefab: characterData2P.CharacterPrefab.gameObject,
            playerIndex: 2,
            pairWithDevice: GameManager.Player2Device
            );

        //���E���h�P�J�n
        RoundData firstRound = new RoundData(2, 2, 1);
        PlayerData playerData1P = new PlayerData(
            characterData1P, 
            player1.GetComponent<CharacterActions>(),
            player1.GetComponent<CharacterState>(),
            1
            );
        PlayerData playerData2P = new PlayerData(
            characterData2P,
            player2.GetComponent<CharacterActions>(),
            player2.GetComponent<CharacterState>(),
            2
            );
        StartRound(firstRound, playerData1P, playerData2P);
    }

    protected virtual void StartRound(RoundData roundData, PlayerData playerData1P, PlayerData playerData2P)
    {
        Debug.Log("���E���h�J�n�I");
        _currentRoundData = roundData;
        _playerData1P = playerData1P;
        _playerData2P = playerData2P;

        CharacterActions ca1P = _playerData1P.CharacterActions;
        CharacterActions ca2P = _playerData2P.CharacterActions;

        CharacterState cs1P = _playerData1P.CharacterState;
        CharacterState cs2P = _playerData2P.CharacterState;

        //�G�ݒ�
        ca1P.InitializeCA(1, ca2P);
        ca2P.InitializeCA(2, ca1P);
        //���S�f���Q�[�g
        ca1P.OnDie = KO;
        ca2P.OnDie = KO;
        //�J�����ݒ�
        _camera.GetComponent<FightingCameraManager>().InitializeCamera(ca1P.transform,  ca2P.transform);
        //UI�ݒ�
        _fightingUI.SetPlayer(playerData1P, playerData2P);
        _fightingUI.HeartLost(_currentRoundData);
        _fightingUI.SetTimeLimitText(_timeLimit.ToString("D2"));
        _effectManager.InitializeFEM(ca1P, ca2P);
        //���E���h�R�[��
        cs1P.SetAcceptOperations(false);
        cs2P.SetAcceptOperations(false);
        RoundCall();

        //���W���Z�b�g
        ca1P.transform.position = new Vector2(_startPosX1P, StageParameter.GroundPosY);
        ca1P.transform.position += new Vector3(ca1P.PushBackBoxOffset.x, 0);
        ca2P.transform.position = new Vector2(_startPosX2P, StageParameter.GroundPosY);
        ca2P.transform.position -= new Vector3(ca2P.PushBackBoxOffset.x, 0);

        KinokoLogger();
    }

    private async void RoundCall()
    {
        await _fightingUI.RoundCall(CurrentRoundData.RoundNum);
        _playerData1P.CharacterState.SetAcceptOperations(true);
        _playerData2P.CharacterState.SetAcceptOperations(true);
        CountdownAsync().Forget();
    }

    private async UniTaskVoid CountdownAsync()
    {
        _timeLimitCTS = new CancellationTokenSource();
        CancellationToken token = _timeLimitCTS.Token;

        int time = _timeLimit;

        try
        {
            while (time >= 0)
            {
                _fightingUI.SetTimeLimitText(time.ToString("D2")); // 2���\��

                await FightingPhysics.DelayFrameWithTimeScale(
                    FightingPhysics.FightingFrameRate,
                    cancellationToken: token
                    );

                time--;
            }

            await RoundSetPerformance(_fightingUI.TimeOver);

            if (_playerData1P.CharacterState.CurrentHP > _playerData2P.CharacterState.CurrentHP)
            {
                GoNextRound(2);
            }
            else if (_playerData1P.CharacterState.CurrentHP < _playerData2P.CharacterState.CurrentHP)
            {
                GoNextRound(1);
            }
            else
            {
                GoNextRound(0);
            }
        }
        catch(OperationCanceledException)
        {
            //�J�E���g�_�E����~
        }
    }

    private async UniTask RoundSetPerformance(Func<UniTask> performance)
    {
        FightingPhysics.SetFightTimeScale(0.5f);
        Time.timeScale = 0.5f;
        _playerData1P.CharacterState.SetAcceptOperations(false);
        _playerData2P.CharacterState.SetAcceptOperations(false);

        Debug.Log("�X���[���o");

        try
        {
            await performance.Invoke();
        }
        catch{ }

        FightingPhysics.SetFightTimeScale(1);
        Time.timeScale = 1;
        _playerData1P.CharacterState.SetAcceptOperations(true);
        _playerData2P.CharacterState.SetAcceptOperations(true);
    }

    private async void KO(int loserNum)
    {
        _timeLimitCTS?.Cancel();
        await RoundSetPerformance(_fightingUI.KO);
        GoNextRound(loserNum);
    }

    private void GoNextRound(int loserNum)
    {
        if(loserNum != 0)
        {
            _currentRoundData.RoundNum++;
        }    

        if(loserNum == 2)
        {
            _currentRoundData.Heart2P--;
            if(_currentRoundData.Heart2P <= 0)
            {
                GameSet(1);
                return;
            }
        }
        else if(loserNum == 1)
        {
            _currentRoundData.Heart1P--;
            if (_currentRoundData.Heart1P <= 0)
            {
                GameSet(2);
                return;
            }
        }
        GoFighting();
    }

    protected abstract void GoFighting();

    protected virtual async void GameSet(int winnerNum)
    {
        _fightingUI.HeartLost(_currentRoundData);

        _playerData1P.CharacterState.SetAcceptOperations(false);
        _playerData2P.CharacterState.SetAcceptOperations(false);

        await _fightingUI.KO();

        if(_playerData1P.CharacterActions.gameObject != null)
        {
            Destroy(_playerData1P.CharacterActions.gameObject);
        }
        if (_playerData2P.CharacterActions.gameObject != null)
        {
            Destroy(_playerData2P.CharacterActions.gameObject);
        }

        //ResultSelectScene�Ɉړ�
        GoResult(winnerNum);
    }

    private async void GoResult(int winnerNum)
    {
        //ResultSelectScene�Ɉړ�
        ResultManager resultManager =
            await GameManager.LoadAsync<ResultManager>("ResultScene");
        resultManager.InitializeRM(winnerNum, _playerData1P, _playerData2P);
    }

    private void OnDestroy()
    {
        if (_timeLimitCTS != null)
        {
            _timeLimitCTS.Cancel();
        }
    }

    /// <summary>
    /// ���̂��̍s�����O�p���\�b�h�ł��B���u��
    /// </summary>
    public void KinokoLogger()
    {
        MovingLog _moving1 = _playerData1P.CharacterActions.gameObject.GetComponent<MovingLog>();
        MovingLog _moving2 = _playerData2P.CharacterActions.gameObject.GetComponent<MovingLog>();
        BattleInfoLog infoLog = new BattleInfoLog();
        _battleInfoLog = infoLog;
        _moving1?.SetBattleInfoLog(infoLog);
        _moving2?.SetBattleInfoLog(infoLog);
    }

    public void KinokoLoggerEnd()
    {
        MovingLog _moving1 = _playerData1P.CharacterActions.gameObject.GetComponent<MovingLog>();
        MovingLog _moving2 = _playerData2P.CharacterActions.gameObject.GetComponent<MovingLog>();
        _moving1.RegisterLogs();
        _moving2.RegisterLogs();
        _battleInfoLog.ArrangeForFile();
    }
}

public struct PlayerData
{
    public CharacterData CharacterData { get; private set; }
    public CharacterActions CharacterActions { get; private set; }
    public CharacterState CharacterState { get; private set; }
    public int PlayerNum { get; private set; }

    public PlayerData(CharacterData cd, CharacterActions ca, CharacterState cs, int pn)
    {
        CharacterData = cd;
        CharacterActions = ca;
        CharacterState = cs;
        PlayerNum = pn;
    }
}

public struct RoundData
{
    public int Heart1P;
    public int Heart2P;
    public int RoundNum;

    public RoundData(int heart1P, int heart2P, int roundNum)
    {
        Heart1P = heart1P;
        Heart2P = heart2P;
        RoundNum = roundNum;
    }
}

