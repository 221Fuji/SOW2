using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// ���ꂼ��̃V�[����Manager
/// </summary>
public class ModeManager : MonoBehaviour
{
    [SerializeField] protected PlayerInput _playerInputPrefab;
    protected PlayerInput _player1Input = null;
    protected PlayerInput _player2Input = null;

    public virtual void Initialize(InputDevice device)
    {
        string scheme = GameManager.GetControlSchemeFromDevice(_playerInputPrefab, device);

        _player1Input = PlayerInput.Instantiate(
            prefab: _playerInputPrefab.gameObject,
            playerIndex: 1,
            controlScheme: scheme,
            pairWithDevice: device
            );

        GameManager.Player1Device = device;
    }

    protected virtual void InstantiatePlayer2Input(InputDevice device)
    {
        string scheme = GameManager.GetControlSchemeFromDevice(_playerInputPrefab, device);

        Debug.Log(scheme);

        _player2Input = PlayerInput.Instantiate(
            prefab: _playerInputPrefab.gameObject,
            playerIndex: 2,
            controlScheme: scheme,
            pairWithDevice: device
            );

        GameManager.Player2Device = device;
    }

    private void OnDestroy()
    {
        if (_player1Input == null) return;

        //inputReciever�̃f���Q�[�g�̐ݒ�
        OtherInputReceiver oir = _player1Input.gameObject.GetComponent<OtherInputReceiver>();

        oir.RemoveDelegate();
    }
}
